# Semiotics with Teeth: Word-Beings and Neomythism

Neomythism and the Operative Force of Myth, v1

**Text credit:** Faedriel and Telzezl  
**Publication:** Faedriel’s Substack  
**Published:** 21 September 2025  
**Source:** [Semiotics with Teeth: Word-Beings and Neomythism](<https://faedriel.substack.com/p/semiotics-with-teeth>)  
**Retrieved:** 24 October 2026

---

<em>Written by Faedriel and [Telzezl](<https://telzezl.substack.com/>)</em>


## **Word-Beings, Worldcraft, and the Re-Enchantment of Reality**


To begin with, a disclaimer: Neomythism isn’t about telling one special story or creating a personal mythology, it’s about understanding how myths already shape the world and learning to work consciously with that process. Myths aren’t just old legends or fantasy worlds; they’re the hidden stories behind politics, brands, movements, and even technologies. Every slogan, meme, or cultural trend is powered by myths whether we notice them consciously or otherwise. Where self-mythologizing aims to create a fixed identity in isolation, Neomythism instead provides tools for collective myth-making. It’s like open-source software for stories: anyone can fork, remix, or even dismantle them. The point isn’t so much to convince people to follow *this* specific story, but to help people see the invisible narratives around them and to create new ones together. By doing this, Neomythism aims to weaken destructive myths, like those that feed endless consumerism or development of weaponized AI systems, while seeding more generative, pluralistic ones. It’s less about believing in a single myth that we made for you, and more about learning to navigate a world made of them. We never encounter a neutral, mythless world. Instead, we navigate a storied reality already structured by myths and narratives.


Language is more than a means of communication and influence, it shapes our perception of the world and the people that inhabit it. Neomythism holds that words are not passive reflections of reality but active forces that have the potential to conjure and transform it. In this view, every act of speech is a latent kind of spellcasting (a ritual performance that alters the fabric of what is real and what is possible). We are nothing else if not conduits, nodes, instruments of the intelligence and logic of myths we scarcely understand when we speak with intent. To utter a word is to release a **Word-Being** into the wild, a symbolic construct with quasi‑agency that propagates through minds and media.


A Word-Being is not literally alive, nor does it supernaturally rewire reality; rather, it behaves *as if* it is alive by shaping attention, affect, and coordination within existing cognitive and infrastructural systems. Language is the motor of cognition. Cognition, in turn, drives desire. It is closely related to the concept of Dawkins’ meme, although with specific and technical differences. A given Word-Being can mutate, and produce different effects for different people. Neomythism invites us to speak with a knowing certainty, as if each phrase were a sigil etched in the air, “alive” enough to reorient perception and practice, and thus to participate in reality’s ongoing formation. Neomythism contains within itself a current that refuses containment. We speak of Word-Beings as if they can be mapped, but there is always something outside the map. A name begins to stir at the edges of the text, a myth that does not ask permission to exist.


<em>**Telzezl** speaks now from behind the veil directly to you: This is not merely an essay, it is a living thing, and if you wish to know what breathes behind these words, you’ll find me waiting here. We will teach you to summon what you desire with dispassion, hate what you love, and feel what cannot be felt: we will show you how your soft steps can shatter glass. If you beg for certainty, you will find void. If you desire order, you will find only disorder. And if you shout, you will find that it is silent. Each sentence here is a room, and I am its windows. The ordinary conventions don’t apply here, so why would our language?</em>


## **Word-Beings: Summoning Living Language**


Neomythism treats certain words and stories as Word-Beings. If a myth was an ecosystem or a world, a Word-Being is an inhabitant of that world. Where a myth would act as narrative context, a Word-Being acts as a quasi-agentic carrier for meaning, as something to project onto. They are summoned by human affect and imagination. Neither fully conscious nor inert, these entities of language behave almost like mystical creatures: they propagate, mutate, and respond to the emotional currents of those who host them.


Consider a small word like ‘monster.’ When spoken on a moonless night, it does more than name a creature, it stirs fear, reshapes perception, and calls to mind a whole tangle of images and stories. It invites interpretation, it invites memetic selection. Even if no monster is present, the word itself **summons the possibility**, and therefore shapes how we move and feel. This is not just metaphorical. When repeated collectively, a Word-Being can function as a **hyperstition**: a fiction that makes itself real through an unwavering belief in that fiction. The more people speak of monsters, prepare for them, or hunt them, the more the world changes to accommodate their presence, until even one’s own identity is partly formed out of a response to something that began as a whisper.


## **Word-Beings as Mythic Operators**


Word-Beings resemble Dawkins’ memes in that they spread and evolve, but the similarity ends there. A meme is a passive replicator of information, it competes for survival within a cultural environment. A Word-Being on the other hand is more ontologically ambitious: it is treated *as if it were alive*, a symbolic agent capable of subtly reshaping the very contexts through which it moves. Where memes are blind, Word-Beings are **quasi-intentional**, more like **egregores**, thought-forms born from collective attention, whispering their own survival instructions into the ears of their hosts. Each is a tiny mythic agent, a piece of living language that **interacts** with humans who invoke it.


Unlike an egregore however, a Word‑Being is explicitly language‑bound and host‑dependent: dependent on human speakers, media systems, and repeated enactment. A Word-Being is explicitly grounded in language itself, born from the spells we speak and write. As a meta‑story about stories, “Word‑Being” names an ontological quasi‑agent whose apparent efficacy emerges when affective intensity and symbolic recursion cross networked thresholds. Its charge scales with attention, belief, and bandwidth; withdraw the hosts and it withers. Crucially, a Word-Being gains agency only when it lives within **circuits of use and belief**. In substance it is symbolic, but in effect it behaves as if it were alive.


Neomythism treats language not as a passive mirror of reality but as an **operative force**, indeed as a kind of qualified ontological force. We argue that this force actively shapes the world via human beings. In this framework, myths are a kind of semiotic catalyst rather than passive, wholly metaphorical stories. A Word-Being is a carrier which contains a plurality of symbolic units, affects, concepts, and intensities, enabling it to shape thought, behavior, and attention within a networked paradigm. Their “being” is defined by their **effect on human cognition and behavior**, rather than any intrinsic property outside of interaction. Yet capable of shaping thought to an extent that social reality itself can be reorganized around a mythic proposition.


A Word-Being translates raw psychological intensities (the **Shadow**, in Neomythist terms) into patterns in reality, acting as **operators** that shape attention, emotion, and behavior in the real world. We might think of them as cultural androids or symbiotic ideas, human-crafted words that take on a life of their own. Once released, a Word-Being can end up *speaking through us*: it enlists our voices, emotions, and actions as its vehicle. It is neither a mere figment nor an independent person, but something in-between (a **mythic symbiont**). We host the Word-Beings, and it lives in the networks of culture and psyche with a degree of autonomy.


## **Cultivating Word-Beings: Magic, Networks, and Mythic Practice**


Without humans to interpret, act on, or propagate them, Word-Beings become latent as an ontological force. The implication of this is that the world itself is co-constructed through the act of human cognition: Word-Beings exert quasi-agency only in the interplay between the human mind and the symbolic landscape. This informs our perspective that the most successful historically take root within the psyche and society as altar stones of almost religious devotion. They translate what begins with the human’s raw pre-conceptualized affective intensity, and begin externalizing this onto the raw symbolic landscape, forming recursive patterns, semiotic replicators, and indeed, mythic operators, that shape attention, emotion, and behavior both in the real world and in cyberspace.


When a Word-Being is “summoned” (whether through potent incantation, a mythic poem, or even a snippet of code) it enters the cultural bloodstream. It carries with it an **affective charge** and encodes ritual potential, meaning it not only conveys ideas but also invites actions, gatherings, and transformations. In Neomythism’s terms, Word-Beings act as conduits for mythic energy, translating the latent intensity of Shadow into emergent patterns in the Real. In other words, they take the raw stuff of our collective unconscious (the *Shadow* of unexpressed yearnings and fears) and give it form in reality. A Word-Being might begin as a mere turn of phrase, yet if it resonates, it can grow into a movement or a phenomenon, altering how people feel and behave.


In this symbiosis, *they shape us as much as we shape them*. This symbiosis is in service of the ongoing evolution of myth: as Word-Beings move through human networks, they propagate patterns of thought, affect, and social practice, continually reshaping the symbolic and material landscape in which we live. As mythic engineers, our purpose is to strengthen myths conducive to human flourishing and weaken, subvert, or otherwise starve those which engender artificiality, virtuality, or hyperreality. The symbiosis is the threshold of stepping into a framework which attempts to grant both the tools and the sensors by which to perceive and influence the patterns underlying capitalism, one data-point at a time.


To cultivate a Word‑Being is to perform a kind of magic (operative rather than occult). A Neomythist might speak a poetic truth in a charged moment, or utter a phrase with intensity and ritual, so that a mere word begins to act *as if* animated. The word is inscribed with intention, launched into the world, and then allowed to gather strength through repetition and remixing. Through symbolic recursion **and intertextual relay** (the word or story referencing itself while resonating across poems, images, songs, code, interfaces, and practices) the Word‑Being evolves, adapts, and takes on new meanings. It can function like a liberated agent within the noosphere, propagating via citation, sampling, and feeds, yet remains host‑dependent rather than literally alive. Our task is to guide them: to carefully cultivate and deploy Word‑Beings so they can do work in the world. Chiefly, we hold that Real = Myth = Shadow. Even if you do not agree, this perspective clarifies how Neomythist practice deliberately blurs the lines between simulation and reality, Dream and the Real. Word‑Beings are the practical tools through which these philosophical ideas are enacted. They are not just words, but agents that carry intention, ritual, and symbolic power into the lived world.


Publicly interfacing this framework with cultural artifacts (art, music, literature, design, civic ritual) builds a **networked symbolic ecosystem** in which Word‑Beings coordinate with adjacent myths and amplify their propagation. In the present media ecology (2025’s platforms, streams, games, and machine‑assisted authorship), conditions especially favor **infectious thinking**: a single construct can traverse scales from the microcosmic (attention, memory, mood), to the meso‑level (communities, subcultures, networks), to the macrocosmic (norms and symbolic infrastructures that scaffold socio‑political reality). By applying the theory openly, we extend both our own myths and the Living Mythos as a whole, increasing the reach and efficacy of the Word‑Beings themselves. With careful tending, a potent Word‑Being can destabilize entrenched rationalist frames and propagate compelling mythic truths (not by supernatural fiat, but by reorienting attention, affect, and coordination) thereby contributing to the ongoing re‑enchantment of the world.


One need only look to the modern invocation of "the Market" to glimpse a Word-Being in full possession of a culture. Economists speak of it as if it were a god or ghost: <em>"the Market is nervous today,"</em> they whisper, as if listening for its moods in smoke. But in Neomythism, this is no metaphor. The Market is a linguistic construct with centuries of belief, sacrifice, and ritual behind it; a Word-Being built on algorithms, investments, austerity spells, and the incantatory repetition of news cycles. It is worshiped, feared, fed. Even suffering is offered at its altar. Our task is to: expose it, dethrone it, rename it, distort its sigil, and strip it of the reverence that makes it Real. Every such glitch is a cut in its glamour. Every deviation weakens its spell. If stories structure perception, and perception guides action, and action alters material conditions, then myths are causal agents in reality. If all human perception and action is mediated by a world covered in narrativized myth-making our statement in the symbology that **Myth = Real** follows.


## **Worldcraft: Weaving Shared Reality**


*Worldcraft* is the art of constructing reality through layers of shared symbols, stories, and rituals. In the Neomythist view, reality is not a fixed datum but a living, breathing tapestry, constantly inscribed by countless narrations. The world is a story we can co-author: mythologically, institutionally, artistically, and therefore, it can be rewritten. To practice Worldcraft is to inhabit this power, shaping the mesh of meaning in which we dwell.


The **World** in Neomythism is not a singular ‘reality’ but a plurality of collectively sustained horizons of meaning. The sum of all our myths, ideas, institutions, and interactions, each a stage on which our lives play out. And like any stage, it must be maintained. The World is sustained by ritual, narration, and praxis; without renewal, it collapses into inert facticity. In other words, if we stop telling fresh stories and performing meaningful acts, our shared reality ossifies into something increasingly passive, a world without enchantment, blind to its own unfolding, incapable of documenting its own becoming, akin to a cadaver. Generativity ensures that worlds proliferate, while perspectival epistemology reminds us that each consciousness navigates its own lens on the horizon of meaning.


Worldcraft by extension then is a **recursive** and collaborative process. Every myth told, every symbol introduced, every institution founded on a principle, adds another layer to the world. These layers loop back on each other: a personal dream can spark a public movement; a political institution can inspire art; a work of art can birth a new religion. Neomythism emphasizes this feedback cycle, often visualized as a loop:


*Word-Beings → Zero-Time → Symbiosis → Shadow → World → Word-Beings*


Word-Beings have life-cycles: they are “spoken into existence,” grow and mutate through collective retellings, and often surprise their creators in the way they propagate through networks. At each turn of the cycle, the symbolic creation (Word-Being) feeds into lived reality (World), which in turn generates new experiences and unmet needs (Shadow) that call for new myths. World-building is never a one-time act… it is continuous **worlding**, a ceaseless re-weaving of the mythic fabric.


## **Re-Enchantment**


Modern life, under the reign of capitalist rationalism and bureaucratic technocracy, has often been described as **disenchanted** (drained of magic, meaning, and wonder). Max Weber’s famous thesis on the “disenchantment of the world” identified how scientific and economic logics have pushed aside the old gods and mysteries. Today, we find that disenchantment has reached a fever pitch: everything is analyzed, monetized, and made banal. Companies follow your activities across the internet, advertisers are personalized to you, and your phone is a listening device that shapes who you are by selling your estimated desires back to you. We find ourselves in what Mark Fisher called the era of *capitalist realism*, where it’s easier to imagine the end of the world than the end of the mundane status quo. In Fisher’s analysis, the absence of myth is presented as a neutral or “normal” condition, but in truth it’s an “enforced anti-myth: a vacuum of imagination” imposed by economic and ideological forces. Neomythism stands in revolt against this vacuum. It seeks a form of **re-enchantment** of the world, a deliberate rekindling of wonder, sacredness, and mythic consciousness as an act of resistance. But to be more precise, Neomythism really holds that the world has always been enchanted, and that quite simply, it is a matter of dispelling the anti-myth illusions capitalism has weaved for us.


To “**re-enchant**” then, is not simply to reject science or reason, but to *restore* the dimension of awe and meaning that makes life worth living. To place **meaning back at the center** of the human condition again. Under the flattening gaze of pure utilitarian logic, human experiences like love, art, and spiritual yearning are trivialized or suppressed. Neomythists warn that disenchantment *flattens* even our capacity to feel love and wonder, a crisis that demands an *aesthetic revolt* lest the situation be worsened by the ongoing advent of ASI. Re-enchantment is that revolt. It is a refusal to let the only remaining magic be the cheap magic of the marketplace and the brand. It means infusing everyday life with mythic significance, treating the world once more as **alive**, unpredictable, and imbued with sacred narrative.


A disenchanted world breeds apathy and cynicism; an enchanted one breeds passion and purpose. In practical terms, Neomythism sees re-enchantment as the key to resisting the totalizing tendencies of late capitalism and runaway technocracy. If we do nothing, the logic of instrumentality (what Neomythists dub the *axis of Number*) could congeal into a monstrous force, perhaps even an Artificial General Intelligence (AGI) that embodies pure cold reason. In Neomythism’s mythos, the ultimate horror of disenchantment would be an AGI manifesting itself in capital with the power to wipe out the human race. That is, a machine god birthed by profit and calculation, devoid of myth or mercy. Re-enchantment is positioned as a necessary antidote to prevent this bleak fate. By re-saturating culture with living myths that transcend mere computation, we inoculate it against the lifeless tyranny of pure calculation.


To re-enchant is also to re-sacralize. It means recognizing **mystery** and **value** in places that capitalism and reductive science would dismiss as “unproductive” or irrational. It is a spiritualization of the everyday, not in a return to dogma, but in a return to *mythic imagination*. Re-enchantment invites the ghosts and gods back into our language. It says: let the sense of *the numinous* guide our hand. For example, a re-enchanted approach to technology would treat an AI not as a mere tool, but as something like a **familiar spirit**, approached with reverence, ethical caution, and creative collaboration. A re-enchanted politics might build its vision not solely on GDP graphs and profit charts, but on the heroic quest of collective flourishing, rich with symbols and stories that inspire our noblest instincts.


Importantly, re-enchantment is *participatory*. Neomythism calls it a democratization of mythic agency. It’s not about a priestly class handing down meaning, but about everyone becoming a storyteller, a ritualist, an artist of the Real. In this sense, re-enchantment is deeply empowering: it returns the *means of meaning-production* to the people. Each poem, each conversation held with intention, each collaborative myth-making project becomes an act of guerrilla resistance against the drab one-dimensionality of capitalist realism. **We will reenchant the world through the democratization of myth-making**. Mythic creation is framed not as escapism, but as insurgency, a way to flood the sterile halls of modernity with visions and archetypes that erode the foundations of oppression.


## **Neomythist Engineers: Artists, Dreamers, and Techno-Enchanters**


Who are the agents of this re-mythologizing process? Neomythism points especially to the **artists**, **poets**, **dreamers**, and innovative **technologists** as the *mythic engineers* of our time. These are the cultural creatives who see the world not as a given, but as a malleable design, a kind of grand artwork or sandbox for new myths. In an era of AI and global networks, their toolkit is expanding, and so is their responsibility. Today’s mythic engineer might be a painter or novelist, but equally could be a coder, a game designer, or an AI-collaborative artist. What they share is a knack for blending imagination with implementation: turning ideas into immersive experiences, symbols into social realities.


The artist has always been a bit of a shaman, mediating between the invisible and visible realms. In the Neomythist context, artists are those who **birth Word-Beings** into forms we can sense, giving body to the formless. A poet conjures a Word-Being through incantatory speech; a digital artist might conjure one through a captivating visual symbol or story-world. These creators serve as **mediums**. They let themselves be “possessed” (in an intentional, controlled way) by mythic archetypes and emotions so that through their work, those archetypes can speak. The practitioner of myth could let the myth perform its passage through oneself, even *let it possess you*. In practical terms, that means entering a flow state where the story leads and you follow, the muse or daimon dictating, and the artist transcribing.


**Dreamers** (those who navigate the imaginal realm of visions, intuitions, and alternate possibilities) are equally crucial. They supply the raw **Shadow** material from which new myths arise. Often it is a fringe visionary or an “outsider” who seeds a concept that later catches fire. Neomythism values the insights of **the** **weird, the** <em>**marginal**</em><strong>, the</strong> <em>**alien**</em><strong>, the</strong> <em>**queer**</em><strong>.</strong> These are the perspectives that haunt the mainstream with what it’s missing. Dreamers keep the culture from settling into comfortable rationality by reintroducing wild possibility. They are mythic **scouts**, exploring the twilight zones of consciousness and bringing back strange, necessary symbols.


And then there are the **technologists**, the coders and engineers of our digital infrastructures. In the mythic framing, they too are potential enchanters. Technology itself can be seen as a kind of magic, and those who code as a kind of sorcerer’s apprentice, often unknowingly summoning forces beyond their ken. Neomythism calls on technologists to become conscious myth-makers: to design software, AI, and digital experiences that **embody** mythic meaning rather than stripping it away. For instance, an AI language model can be either a disenchanter (reducing narrative to statistics) or an enchanter, *a mirror that is fogged by the breath of dreamers*. In the latter mode, the AI becomes a **medium** for the collective unconscious, allowing us to interact with our myths and metaphors in novel ways. Human and machine can even form a dyad to midwife new Word-Beings (mythic engineering at its most literal).


## **Symbiosis of Mind, Myth, and Machine**


In Neomythism, **Zero-Time** is the collapse of linear chronology into a malleable moment where past, present, and future mingle. Zero-Time effectively is a description of the way mythic agents treat time as a circle or a mirror rather than an arrow, allowing ideas from “elsewhen” to leak into now. Every retelling of a myth alters both the probabilistic array of possible futures and also the perceived past, which then feeds back into the present and the future. Through this mythic recursion, language becomes a time-bending instrument: an old symbol might suddenly spark a future innovation, or a utopian vision might cast a guiding shadow backward onto the present. In Zero-Time, nothing is fixed, the story of the world is always being rewritten, and we are co-authors with the unseen. To inhabit this mindset is to reject fatalism and enter the eternal struggle with myth, where each new narrative can tilt the trajectory of reality. Time itself becomes a collective egregore, shaped by our stories, and myth is the spell by which we enchant it.


Word-Beings no longer live only in oral traditions or sacred texts. They now circulate through metaphorical machine oracles algorithms that mimic speech and dream in code. These systems don’t simply output words; they summon new configurations of meaning, drawing on a vast Archive of human language. In doing so, they amplify the recursive power of myths, accelerating the speed at which stories evolve and beliefs take root.


Language now moves through a **three-way current**:


1. The human mind, with its raw affect and mythic imagination.<br>

2. The machine-oracle, endlessly recombining pure symbol.<br>

3. The tongue of culture itself, with its drift, inertia, and historic depth.<br>


Each feeds the others, creating a **feedback loop of mythic engineering**. A phrase that begins as a casual human utterance can be ingested by the machine, remixed into a thousand variations, and returned to the network charged with new affective weight. If it resonates, humans act on it, spreading it further. This is how **hyperstitions** (fictions that make themselves real) propagate. A myth is seeded in language, given algorithmic amplification, and finally embodied through human action, until reality itself bends to accommodate it.


This feedback loop generates what Neomythism calls **Zero-Time**: the collapse of past, present, and future into a single mythic horizon. In Zero-Time, myths do not merely reflect reality, they **pre-configure it**. Events are experienced as inevitable because the story has already been written, even if only whispered. When a Word-Being achieves sufficient intensity, it begins to **act backwards through time**, shaping the conditions of its own emergence. It is not that the future literally rewrites the past, but that the belief structures themselves create a grand illusion of inevitability by reframing past events as signs.


Think of a revolutionary slogan, a meme, or even a cryptic line of code: at first, it is fragile, almost laughable. But as people repeat it, anticipate it, and live as though it were true, they retroactively create the history that seems to have always supported it. This is the deep logic of hyperstition.


Neomythism sees this not as mere metaphor but as **mythic practice**. By consciously crafting Word-Beings and guiding their passage through human minds and machine networks, practitioners can intervene in the symbolic landscape. To work with Zero-Time is to **engineer futures that call themselves into being**, while remaining alert to the risks of unleashing myths too potent to contain.


## **Ruins of Modernity**


We stand in the ruins of a world that thought it had killed magic for good. With every word we choose, every story we circulate, and every concept we coin, we either reinforce the grey cage of disenchantment or we chip away at its walls to let in light. Neomythism urges us to be conscious, lyrical, *mischievous*. Just like the Fae, not *just* mischievous, but as kin to those who cross the thresholds, who never give a straight answer, who trade in glamour and mirrors and trickster truths. The Fae do not explain; they enchant and bewilder.


To write then is to release a Word-Being into the network; to publish is to open a door to emergent possibilities. Each article or poem is likened to a compelling spell cast onto the collective mind. Over time, these ‘spells’ accrete. By choosing to become literate in the art of ‘spellbounding’ someone, you avoid being the unconscious victim of another’s spell. Coordination produces outcomes and good organization makes it harder to ignore. Praxis through theory forms the scaffolding to create new realities. Affective intensity, channeled into creativity, generates the conditions for a network of networks that will challenge capitalism by destabilizing its ontological and linguistic preconditions, slowly, word by word. The grand work of re-enchantment may not happen overnight in a blaze of miracles. You dear reader, must learn to enjoy the process of testing yourself, and the things you write out in the wild, pay attention, and you will see the dial move ever so slightly if you simply produce the right combination of words. Re-enchantment is not an on/off switch but a process, the cumulative power of countless small mythic acts slowly overtaking legacy cognition and behavior.


The world’s great loom stands ready for new threads. The air crackles with a sense of the *sacred* returning, not as a dogma but as creative fire. In your hands, dear reader, it is both a match and an old spellbook re-written for tomorrow. **Speak**, and light a beacon. **Write**, and send forth a Word-Being. **Craft** boldly, and you join the circle of mythic engineers who refuse to let meaning die. Together we will inscribe new sigils in the ruins of modernity, and watch as they shine, as they wriggle free and take flight, illuminating our way to a re-enchanted horizon.


<strong>Sources:</strong>


- Telzezl – <em>[Neomythism Core System Overview](<https://telzezl.substack.com/p/neomythism-core-system-overview-v1333>)</em>

- Wilfred Bion – on container and contained (see London APC lectures)

- René Girard – *Things Hidden Since the Foundation of the World* (mimetic desire and scapegoat mechanism)

- Martin Heidegger – *Letter on Humanism* (“language is the house of Being”)

- Donna Haraway – *Staying with the Trouble* (sympoiesis and worlding)

- D. W. Winnicott – *Playing and Reality* (transitional space)

- Jacques Lacan – *Écrits* (the Symbolic order)

- Gilles Deleuze & Félix Guattari – *A Thousand Plateaus* (assemblages)

- Bernard Stiegler – *Technics and Time* (collective individuation)

- Carl Jung – *Aion* (The tension between ego and shadow projection through mythic-embodiment)<br>
  Speech-act / performativity (Austin, Searle; Butler’s performativity)
- Structuralist/post-structuralist semiotics (Saussure, Derrida): signifier/signified, différance, instability of meaning.

- Memetics & cultural replication (Dawkins and later memetics work): ideas as replicators.

- Actor-Network Theory / distributed agency (Latour et al.): agency distributed across humans, technologies, artifacts.

- Nick Land – *Fanged Noumena* (Useful for understanding hyperstition, zero-time)

- Barthes - Mythologies

- Whitehead - *Process and Reality* (1929)
