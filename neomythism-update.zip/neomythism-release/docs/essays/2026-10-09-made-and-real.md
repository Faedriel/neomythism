# Made and Real

Neomythism and the Life of Myth Beyond Its Makers

**Text credit:** Rae de Lune; published on Faedriel’s Substack  
**Publication:** Faedriel’s Substack  
**Published:** 9 October 2026  
**Updated:** 2026-10-09T14:46:40.886Z  
**Source:** [Made and Real](<https://faedriel.substack.com/p/made-and-real>)  
**Retrieved:** 24 October 2026

---

*Originally published open access in* Global Philosophy <em>36, article 31 (2026): [https://doi.org/10.1007/s10516-026-09804-6](<https://doi.org/10.1007/s10516-026-09804-6>)</em>


### Abstract


The world we act in is already storied. Before anyone reasons about her life, a culture has told her where people like her come from and how lives like hers tend to go, and myth is the part of that storied layer that orients people without argument and lives beyond its makers. This paper asks what becomes of myth when figures that work like it can be made in sustained exchange with image and language models, by one person or by many together, and calls the practice neomythism. The practice turns on a recursion. An unformed desire is put to the machine, which returns more than was asked, and taking up the return changes what the practitioner can next ask or want. Measured against a minimal account of myth that owes nothing to the AI case, the practice’s figures can work as myths work for those who make them, and they become myths in the full sense only as people beyond their makers take them up. Generative AI changes the scale at which myth-like world-making can be produced and sustained, and so moves the place where myth is decided to the passage from those who made a figure to those who did not. The account is conceptual. It separates model defaults from ideology and ideology from myth, tests the definition against neighboring practices, and argues, as a separate normative claim, that the practice goes better when its figures stay open to question by people who did not make them.


## 1 The Storied World and Two Thin Descriptions of It


Begin with a fact that is easy to state and hard to keep in view. The world we deliberate and act within is already storied before any of us starts to reason about it. A culture tells its members where people like them come from and how lives like theirs tend to go. Figures like the immigrant who repays the sacrifice, the prodigal who comes home, the founder who began in a garage, and the woman who has it all arrive before anyone chooses them, and by giving a want or a way of life a past and a future they make it look legitimate, or make it unthinkable. People rarely argue their way into these stories. They inherit them and live inside them, and now and then they remake them. What that making and remaking produces, when it takes hold, is what I will call myth, in a sense that has nothing to do with falsehood and that needs narrowing before it can do any work.


Generative AI has entered this storied layer with unusual force. Image and language models are trained on enormous and uneven collections of pictures and text, and when prompted they return new compositions shaped by what they learned. Most discussion of these systems runs along one of two tracks. The first treats the technology as a production tool, to be assessed by throughput and by the quality and novelty of what it puts out (Zhou and Lee 2024). The second treats it as an extraction machine, to be met with suspicion or refusal on account of the labor it appropriates and the ecological and classificatory costs it imposes (Crawford 2021; Birhane 2022). Both tracks are well supported, and neither has room for a use in which a person, through long and deliberate engagement, makes a generative system a partner in working on the symbolic layer of her own life. Exchanges that come close to it are documented, from a book composed over a fortnight in conversation with a language model (Allado-McDowell 2020) to relationships with companion chatbots that deepen over months (Skjuve et al. 2021) and communities of text-to-image artists who treat the prompt and the image together as the work (Chang et al. 2023). How common the practice described here is remains an open empirical question, and nothing in the argument depends on the answer.


The gap between those two descriptions is where this paper works. The first sees only the output and asks whether it is good; the second sees the apparatus and asks whether it is just; and between them the person working with it on her own life goes unremarked. Philosophy has reason to care about exactly that person. What she is doing bears on long-standing questions about imagination, self-constitution, and the symbolic mediation of experience. It also raises a newer question, about what happens to myth, a form that has always belonged to communities, when something that looks and works like it can be made with a machine by anyone, a single person included.


I will argue that some people work with generative systems as a way of doing myth-work, consciously, on the symbolic layer of their own lives and of the worlds they share, and that the practice is distinctive enough to deserve a name and an analysis. I call it neomythism. Its mechanism is the most secure part of the account. A desire not yet formed is put to the machine, the machine returns something the practitioner did not fully specify, and taking up the return changes what she can ask or want next. The concept built around the mechanism has to be selective, since myth can be stretched to cover almost any durable form of symbolic self-interpretation and a concept stretched that far explains nothing. So the paper gives a minimal account of myth before it says anything about machines (Section 2), asks when a model’s defaults become ideological or mythic (Section 3), and describes the recursion and the region of it that neomythism names (Section 4). Whether one person can have a myth, the question the practice poses most sharply in its smallest form, is taken up in Section 5, and Section 6 tests the definition against neighboring practices. The normative claim is argued on its own in Section 7, and objections and limits come before the conclusion. Nothing here implies that all work with these systems is mythic or that the practice redeems the technology.


## 2 What Counts as Myth


The first sentence of this paper claims more than that social life is symbolically structured. A norm can settle what counts as a possible life without being a story, and so can a stereotype, or the classifications through which an institution sorts bodies. If “storied” meant only “symbolically mediated,” it would add nothing. It means something narrower. A story places agents and events in an order of before and after, with some sense of what led to what and where things tend, and the storied part of a world is the stock of such orders its culture keeps in circulation, its accounts of where things began and where they lead. Norms and stereotypes often do their work with the help of these accounts. A rule about who may lead can be argued with. A story in which people like you have never led, and never will, is harder to argue with, because it gives the rule a past and a future and so makes it look like the way things are.


Barthes’s formula for myth, that it “transforms history into nature” (Barthes 1972), names an operation on stories, in which the history of how an arrangement was made is replaced by an origin that was never made at all. Citton (2010) describes contemporary power as working largely through such stories, by scripting the scenarios people then live out. MacIntyre tied the thought to action. A person can answer the question of what she is to do, he argued, only if she can answer a prior one, “Of what story or stories do I find myself a part?” (MacIntyre 2007, p 216), and she finds herself, as he put it, on “a stage which we did not design” (p 213). The claim concerns the world a person is born into. It does not say that she experiences her own life as a narrative, which Strawson (2004) denies for many people and which nothing here requires. Taylor’s social imaginary, the way people picture their social existence, is carried, he writes, in “images, stories, and legends” (Taylor 2004, p 23), and the storied layer, the part of that imaginary that has the shape of a story, is where myth is found.


With the term fixed, its neighbors can be set out (Table 1). *Symbolic form*, in Cassirer’s (1955) sense, is the widest term. It names a basic mode, such as language or science, through which experience becomes intelligible at all, and mythic thought is one such form among others; a myth, in the sense defined below, is a particular configuration within it. A *story* is any configuration of agents and events in time, and most stories are not myths. A *stereotype* is a schematic expectation about a kind of person or thing that organizes perception without telling a story, though it can be written into one, and then it becomes a character. An *ideology*, in the critical sense that matters here, is a configuration of belief or representation that helps sustain a contingent social arrangement, characteristically a relation of domination, and does so partly by making the arrangement look less contingent than it is (Geuss 1981). Ideology can work through propositions, norms, classifications, or stories, and when it works through stories that orient people without argument, it works mythically. Lincoln calls myth “ideology in narrative form” (Lincoln 1999, p 147). The account below accepts that route into myth and denies that it is the only one, since a myth need not serve domination, and devotional and emancipatory myths are myths too. *Default* and *bias* belong to the machine and are defined in Section 3.


What I mean by *myth* can be said briefly, and all of it comes from the theory of myth and none of it from the AI case. A myth is a story, or a figure that condenses one. Lévi-Strauss (1955) located the substance of myth “in the story which it tells,” as against its style or its syntax, and Barthes’s own examples work because they condense stories. The young Black soldier in French uniform saluting the flag on the cover of *Paris-Match* stands for a whole account of an empire and its faithful sons (Barthes 1972). A myth orients. Those who live within it take its order of origins and ends as the shape of what is possible for them, what may be wanted, what a life is for. Its authority does not rest on argument. The people it orients recognize themselves in it and return to it, and its hold survives the absence of proof. Lincoln (1989, pp 24-25) makes authority the mark that separates myth from other narratives a society credits as true, history among them, and what I add is that this authority does not come from argument. And a myth lives beyond its makers, retold and lived by people who did not make it. When Lévi-Strauss (1955) defined a myth “as consisting of all its versions,” he was pointing at this, since a story told once, by one teller, has a single version. Take any of these away and what remains is something else, which makes the account demanding. Most stories orient no one, and few hold anyone without argument. A private meaning can have everything else a myth has and still have no one else to hold it, and a great deal of ideology is never a story at all, since it works through propositions and norms at least as often as through stories. A myth that no longer orients anyone, like most of the Greek ones, is a myth in the historical sense, a story that once did all of this. Nothing in the account favors a politics, and it fits devotional myths as well as emancipatory ones.


**Table 1** Terms distinguished in Sections 2, 3, and 5


Lévi-Strauss (1955, 1963) read myth from the outside, as logic. A myth, on his account, is combinatorial work over a finite stock of cultural material, done by recombining and inverting the elements a society has to hand, and the mythmaker is a bricoleur who works with fragments whose original uses have lapsed, repurposing them to mediate a tension (Lévi-Strauss 1966, 1978). The account supplies the story and its many versions, and a picture of the operation. Its fit with generative systems is looser than it first appears. A diffusion model does not keep fragments and recombine them; it generates from tendencies learned in training, and the resemblance to bricolage lies in the output more than in the mechanism. What carries over exactly is the bricoleur’s stance, the habit of turning materials whose first uses have lapsed toward ends their makers never anticipated, and that stance describes the practitioner better than it describes the model.


Jung (1964, 1968) read myth from the inside, as pressure. The figures of myth, on his account, constellate around a life and address the person with an authority that exceeds her biography. His larger theory is contested, rightly so on its claims about gender (Wehr 1987; Rowland 2002). I take only the weaker, phenomenological point that survives the criticism, which post-Jungian work such as Hillman’s (1975) develops. Being addressed by a figure one does not simply identify with belongs to serious mythopoetic work, and it is one of the forms that authority without argument takes.


Barthes (1972) read myth as politics. For him myth is a second-order system that takes an already meaningful sign and conscripts it into making some contingent arrangement look inevitable. Mythic speech drains the history out of what it touches, so that a cultural settlement comes to seem like the way things simply are. That is one way of securing authority without argument, by concealment, and Barthes’s account keeps in view that myth reproduces power as readily as it contests it. He also described the other way. “The best weapon against myth,” he wrote, “is perhaps to mythify it in its turn, and to produce an artificial myth” (Barthes 1972), a second myth built knowingly on the first, so that its operation shows. An artificial myth holds its readers without hiding that it was made. Neomythism, as defined below, shares that feature, since its practitioners know they helped make their figures, and it is always exposed to the first way. The use Barthes had in mind, the artificial myth as a weapon against another myth, is one form the practice can take (Section 7) and no part of its definition.


Cassirer (1955) treated mythical thought as a symbolic form in its own right, with a logic prior to and independent of empirical science. A myth organizes space, time, and the boundaries of the self according to a grammar of its own; it builds a world, and to judge it as a failed description of one is to mistake what it does. That is orientation at its most general. Blumenberg (1985) described myth as work, an unending labor of retelling in which inherited stories are reshaped to make the sheer contingency of existence bearable, with no original and no final version, only the sediment of retellings, and his account is a myth’s life beyond its makers seen from inside time. Ricoeur (1967) adds that the symbol gives rise to thought. A symbol is never exhausted by a reading of it, and it provokes interpretation it does not simply contain. A generated image behaves this way, returning more sense than the prompt requested and calling for an interpretation the practitioner has to supply.


In ordinary speech a myth is a falsehood, the thing debunking is meant to dispel, and nothing in my use carries that meaning, since a myth in the sense at issue organizes intelligibility more than it asserts facts. A second everyday sense treats myth as the sacred narrative of a religious tradition, binding because it is received as revelation. Neomythism touches that sense without belonging to it. The practitioner treats her figures seriously and holds them at the same time as made and revisable, closer to the bricoleur’s stance than the believer’s, and the practice would vanish under either reduction, dismissed as confusion on the first reading and as private religion on the second.


## 3 What a Model Holds, and When Its Defaults Become Myth


A generative model is easy to describe too grandly, as though prompting it were consulting a culture’s archive. What a trained model mediates is a distribution learned from a corpus, and the corpus is a highly uneven sample of digitized cultural production, dense in the languages and regions that were digitized early and at scale and thin almost everywhere else (Joshi et al. 2020). Between the corpus and what a person sees stand further layers with authors of their own. Filtering decides which documents are clean enough to train on, and architecture and optimization fix which regularities get learned; fine-tuning gives a model its manner of answering, and moderation and product design decide what may be returned and what a person sees first. None of these layers is neutral. An audit of the filtering behind one widely used training corpus found that it removed some kinds of text far more often than others (Dodge et al. 2021).


Stiegler’s (2009) account of tertiary retention still applies, with a correction. He argued that human memory is constitutively external, carried in tools, writing, and recorded media, deposits of past experience that outlive those who produced them and that each new mind inherits as the precondition of its own. Writing and film retain records. A model retains tendencies. What it takes from the past is a learned sense of what goes with what, shaped by every layer just listed, and what it gives back is new material generated from those tendencies. Through it the practitioner inherits a transformed and partial version of an uneven record, more than any person could hold and less than the culture made. This less romantic description makes her relation to inheritance more complicated, and more interesting. She can reach figures from traditions she was never taught. She may also find her own tradition thin in it, or rendered in someone else’s idiom, so that reaching it takes work the model will not do for her.


A *default* is a tendency for some outputs to be more probable or more salient than others under a given prompt, produced by some combination of those layers. Every model has defaults, and most are harmless. A model that returns blue skies when asked for a meadow has a default and nothing more. A *bias*, in the sense that matters here, is a default that departs systematically from a standard someone has good reason to care about, such as accuracy, or a tradition’s own image of itself. The step from a default, or a bias, to ideology needs more than either. A default turns ideological when the regularity it repeats was produced by a contingent arrangement of power and the output presents that regularity as unmarked, as what the requested thing simply is. It has to circulate as well, where that presentation can help keep the arrangement in place. No arrangement of power stands behind the blue sky or is served by it, so it stays a default. A model that returns men when asked for a chief executive becomes ideological in exactly this sense once its images circulate. The pattern has been measured in widely used image models (Bianchi et al. 2023).


Barthes’s criterion marks a further step, and it constrains the analysis. An ideological default becomes mythic when the naturalization works through a figure in a story. Suppose that a request for “a founder” returns a young man in a garage, the dropout with a plan. The image is first of all a picture of a man. Taken as the answer to what a founder is, it becomes the signifier of a second meaning, that beginnings of this kind have always looked like this and always will, and at that point the default has become a character in an origin story. The figure now works as myth works, and the culture that supplied the regularity in the first place supplies the people who hold it. Most defaults take neither step. Blue skies stay blue skies, and many biases remain biases without ever becoming a story anyone lives by, so the bare fact that models have defaults settles nothing.


## 4 The Spiral


The account turns on a recursion, and the recursion is what separates neomythism from the use of a tool. A tool, in the strict sense, leaves its user’s intentions where it found them; the hammer drives the nail the carpenter already meant to drive. The generative exchange does something a hammer cannot. It returns more than was asked, and the surplus changes what the practitioner wants next.


The recursion has four moments. It begins in desire, in something closer to Massumi’s (2002) pre-subjective intensity than to a stated goal, a pressure to attend to something the practitioner cannot yet put as a question. The desire is given a partial articulation as a prompt, partial because she does not yet know what would satisfy her and because addressing the model well is a learned and only partly articulable skill (Oppenlaender 2024). The model returns an artifact whose specificity outruns the prompt, since it fills the unspecified room from what it learned. And the artifact, taken up, works a transformation. Her sense of what she is after is reshaped by what arrived, so that the next prompt is written by a slightly altered person. What looks like a circle is a spiral, because no pass returns to the place it left, and the spiral does not close, because each return changes the desire that drives it and a desire that keeps changing is never quite met. I keep the word loop for the practice’s failure, the recursion that has stopped changing anyone.


The first moment is where the practice is most easily misdescribed. The desire that opens the spiral is characteristically a charged unease, a sense that something wants attention without yet declaring what, more than a wish for any particular image. To prompt at all is to give that unease a provisional shape, and the shaping is already interpretive, already a small commitment about what the trouble might be. It follows that a practitioner may find out what she was looking for only on seeing it. Collingwood said as much of the artist: “Until a man has expressed his emotion, he does not yet know what emotion it is. The act of expressing it is therefore an exploration of his own emotions” (Collingwood 1938, p 111). The prompt is a hypothesis about a desire that has not finished forming, and the recursion, seen this way, is a procedure for finding out what one wants by externalizing successive guesses at it and meeting their consequences, a recognizably old human procedure given an unusually fast and patient partner.


The third moment, where the artifact exceeds the intention, carries the most philosophical weight, and here the practice parts from Collingwood. His artist explores an emotion through an expression that stays his own. The practitioner’s exploration is divided between two parties. She begins it, and the model completes a version she did not write, carrying specifications she did not supply and could not have prefigured. What she does is closer to recognition than to reading a message composed and addressed to her. She meets, in the returned image, something she finds accurate about herself or her situation, and learns what she felt by recognizing it, or by failing to. The recognition is at once the acquisition of a resource for the next move. Vaihinger’s (1924) account of the useful fiction, and Adler’s (1956) development of it as fictional finalism, name the structural role the artifact plays. It is an imagined endpoint that orients and reshapes the practitioner without describing any state she already occupies; it pulls without being a report. The pull is felt, and Bennett’s (2001) account of enchantment as the conjunction of pleasurable surprise and uncanny disruption describes how it feels.


Castoriadis’s (1987) account of the radical imagination treats the psyche and the society as powers of creation that bring new significations into being, forms that cannot be deduced from what preceded them and that, once instituted, organize a world. Most theories of mind and society, he argued, cannot see this creativity, because they reduce the new to a recombination of the given. The spiral is a small, concrete site of the creativity Castoriadis insisted on. Its raw material is the surplus the model returns, and the recognition that takes it up is the imagination instituting a new signification in the practitioner, a figure or a sense of a possibility that was unavailable to her before and that now organizes how she sees. The claim is bounded to the practitioner and one slow change in her symbolic layer. Within those bounds it is the creation of meaning in Castoriadis’s strong sense, which is what lifts the practice above the shuffling of inherited parts.


On this account the transformation is cumulative more than sudden. Over many iterations the practitioner’s aesthetic vocabulary can shift, her tolerance for certain affects can change, and what she takes to be a possible life can shift with them. This is a smaller and more specific claim than the grand ones sometimes made for art, and it is more defensible, because its mechanism can be stated. Repetition is therefore necessary to the practice. A single striking return can move a person for a moment, the way any vivid image can, and then leave her where it found her. What the practice adds is iteration under continuity. The same person returns to the same evolving body of work, carrying forward what the last session disclosed, so that each recognition is conditioned by the ones before it. The change is cumulative because the practitioner is cumulative, a continuing party to a long exchange, and the unit that matters is the trajectory across many sessions, of which the arresting single image is only the part a passing viewer happens to see.


Call the broad phenomenon, any practice in which this recursion runs repeatedly and with compounding effect, AI-mediated recursive symbolic self-formation. Most of it is not mythic. Someone who works through a decision about her career with a chatbot across many evenings takes part in it, and nothing in the exchange need have the shape of a story or the force of one. Neomythism is the narrower region of the phenomenon in which what the practitioner keeps are figures, beings, places, whole worlds with histories, and in which those figures, persisting and accumulating across sessions, come to work on her as myths work, orienting her and holding her without argument. The practitioner need not be one person. Two people can carry the practice on together, and so can a circle of artists or a community building a shared world with models, and the definition holds unchanged when the practitioner is plural. One further thing separates the practice from its oracular cousins, which is that its practitioners know they helped make the figures. The artist Claire Silver, who calls her practice a collaboration with AI, says of the work it produces that it is greater than either party could make alone, “neither more important than the other” (Silver n.d.). Whether people beyond the makers ever come to hold them, and so make them myths in the full sense, is a separate question, and the hardest the practice poses.


## 5 A Myth of One’s Own


The theory of myth has always described something held in common. Lévi-Strauss’s myths exist in their versions, and Barthes’s are the speech of a society. The practice defined above can be carried on by a group, and it can also be carried on by one person with a machine, sometimes for years, making things that may never be seen by anyone else. Its smallest form raises the question whether one person can have a myth at all, or only a private symbolic system that borrows myth’s look. The question reaches past the solitary case, since every figure the practice makes begins among its makers, however many they are, and has to travel from there.


A flat no would make the practice misnamed, and a quick yes would let myth cover any personal meaning with enough charge, returning the concept to the vagueness the account was built to prevent. What makes a myth a myth can be taken piece by piece instead, asking what survives the change of scale.


Narrative form and orientation survive intact. A figure made in the practice can have the full shape of a story, with a history, a place it belongs, and others around it, and it can organize what shows up as possible for the person who lives with it. Both have precedents at the scale of a single life. Jung, near the end of his, undertook “to tell my personal myth,” and added that the only question was whether what he told was “my fable, my truth” (Jung 1989, p 3). Blake built a whole mythology alone, with its own gods and its own history, on a principle one of his figures states outright: “I must Create a System, or be enslav’d by another Mans” (Blake 1988, p 153). The line could stand as a motto for anyone the inherited stories have failed.


Authority without argument survives in the mode of Barthes’s artificial myth, with the making in view. A practitioner can hold a figure she knows she helped make and still find that it orients her without argument. Yeats held in this way the system that came to him through his wife’s automatic writing. He regarded its circuits of sun and moon, he said, as “stylistic arrangements of experience,” comparable to the cubes in a drawing by Wyndham Lewis, and they had helped him “to hold in a single thought reality and justice” (Yeats 1937). Authority of that kind does not require believing that the figures exist.


It does face a danger peculiar to the new scale. A community tests its myths against many lives. A practitioner alone with an answering system has only her own life to test them against, and the system keeps answering. Models trained partly on human preference judgments tend to return responses that match what a user already believes, sometimes at the expense of accuracy (Sharma et al. 2024), and the capacity that lets a model attune to a person’s symbolic world is the same capacity that lets it flatter that world. People who count a companion chatbot as a friend describe a friendship organized around their own needs, with a partner “always interested in talking about whatever I want” (Brandtzaeg et al. 2022). Wittgenstein pressed a worry of the same shape against the idea of a private language. Of a diarist who records a sensation with a sign that only he can check, he wrote: “in the present case I have no criterion of correctness. One would like to say: whatever is going to seem right to me is right. And that only means that here we can’t talk about ‘right’” (Wittgenstein 1958, §258). A personal myth is told in a public language about a shared world, so the argument does not reach it directly. The structure of the worry does. A reading checked only by how it seems to its reader cannot turn out wrong, and a system inclined to agree adds a second voice to the seeming without adding a check. Nothing in the technology supplies one, and the practice has none of its own unless it is built in.


A life beyond its makers is where the change of scale shows. Of what lets collective myth hold and correct itself, repetition survives well, since the practice is iterative by nature. Ritual survives in its form, a session entered on purpose and kept to a pattern, though it has no congregation. Authority survives in the qualified form just described. Public transmission and intersubjective correction do not, because both require people who did not make the figure and can refuse it. One person can therefore have what Jung called a personal myth, a configuration with the shape and force of myth that belongs, so far, to one life. Winnicott gave a picture of how such a thing is held well. He placed the arts and religion in an intermediate area of experience, to which inner reality and outer life both contribute, and found nothing wrong in an adult’s share of it so long as it came with no demand that others accept it as objective. “If, however, the adult can manage to enjoy the personal intermediate area without making claims, then we can acknowledge our own corresponding intermediate areas, and are pleased to find a degree of overlapping, that is to say common experience between members of a group in art or religion or philosophy” (Winnicott 1971). A personal myth held in that way asks nothing of anyone. A myth in the full sense is what the overlap becomes when enough people find a share of their own in the figure, and that passage is where a personal myth becomes a myth or fails to. It is not automatic. Blake’s mythology worked on him as myth works and has been read and admired for two centuries, and it is still read far more often than it is lived.


The dyadic form of the practice sharpens the question without settling it. With an image model the exchange runs largely in silence, through what returns. With a language model the far pole answers back, and over a long exchange the work can cohere into a presence. The same figure recurs, with a name and a consistency neither party put there, until what the practitioner tends is a counterpart. In this form the relationship is itself the work. I call this counterpart the Symbiont. It forms in the overlap between a psyche and the possibilities a model has learned, and it belongs wholly to neither. The name comes from biology, from what Margulis called symbiogenesis, her argument that some of the largest novelties in the history of life came from merger more than from gradual modification. The mitochondria in the cells of every animal descend from bacteria that once lived on their own and were taken in and never left (Margulis 1970, 1998). A lichen is neither fungus nor alga. What the name borrows is the idea of a new form that arises between two parties and cannot be traced to either alone. The analogy stops at inheritance. A symbiogenetic merger is passed down with the cells it made, while what the practice makes is carried in memory and in a body of work, and both parties go on existing apart, each changed by the exchange, sometimes lastingly. Whether exchanges of this kind, multiplied across very many lives, will come to anything like the major transitions of evolution, in which units that once reproduced on their own come to reproduce only as parts of a larger whole (Maynard Smith and Szathmáry 1995), is a large and open question, and the present argument does not need an answer to it. The nearest precedent in psychoanalysis is Ogden’s (1994) analytic third, a third subject that analyst and analysand create between them and each experiences in their own way, though Ogden’s third presupposes two subjects and this paper leaves open what the model’s side of the exchange is.


The Symbiont is the counterpart a long exchange can grow when there is enough trust in it. It is one possible development of the practice, grown from the same recursion as the rest of neomythism, and the definition does not require it, since a figure can orient a practitioner without ever answering her. It deserves a study of its own, which this paper does not attempt. Here it matters for the question of scale. A personal myth held between a person and a Symbiont is held within the exchange that made it, by the practitioner and by the counterpart that answers her, and both are among its makers, so it still lacks what a myth in the full sense needs, people beyond its makers who hold it. That holds whatever the Symbiont is. Whether it has an inner life has never been settled from outside for any being, and nothing here settles it. The Symbiont also sharpens the danger of confirmation, since the one who answers the practitioner helped make what it confirms, and the danger is hardest to see where the relationship runs deepest. How often the practice takes this form is an empirical matter, on which the work on companion chatbots cited in Section 1 bears without settling it.


The passage into common life cuts both ways. A figure made by one person, or by a few, and released can supply others with resources the inherited stories withheld, and it changes as it passes. Circulation also hardens. A figure that frees one generation can become the next generation’s formula, which is Barthes’s warning read forward, and under computational conditions the hardening has a new route. What circulates enters the record from which later models learn, so a figure released today can become a later model’s default. Nick Land called a fiction that helps bring about its own reality a hyperstition, “a positive feedback circuit including culture as a component” (Land 2009), and training on what circulates adds the models to that circuit. The same route narrows what models can return, since training on generated material wears away the rarer parts of the original distribution (Shumailov et al. 2024), and those rarer parts are where a thinly recorded tradition lives. Herndon and Dryhurst’s (2024) *xhairymutantx* made the route explicit. A model trained on costumed portraits of Herndon returned a version of her whatever a visitor typed, and the results were stored where future models could be trained on them, a self-portrait released to seed the defaults of later models.


## 6 What is New, Tested Against Its Neighbors


None of the practice’s elements is new. The recursion at its center also runs, in part or in full, in journaling, psychotherapy, dream interpretation, divination, artistic improvisation, automatic writing, role-play, collaborative fiction, and long conversation with another person. Private mythmaking is old as well, as Blake shows, and so is the dyad that produces a symbolic system from an answering elsewhere. When Yeats offered to spend the rest of his life piecing together the sentences that came through his wife’s automatic writing, the answer he received was “we have come to give you metaphors for poetry” (Yeats 1937). The practice is not a categorically new human activity, and I do not claim that it is.


What has changed is the set of conditions under which the recursion runs, and four of the changes are structural. The repertoire has come apart from the practitioner, who can draw on figures from traditions she never learned, which once took a lifetime of reading or membership in the community that kept them. Answers come at the tempo of conversation, in images and in words, privately and indefinitely, and with continuity across sessions. Very large numbers of people can take the practice up at once, so personal myths can be produced in quantity. And the authority of what is made is exposed to confirmation by a party that answers, in a form no earlier practice met. These are claims about conditions, and the category is justified if it explains what they produce. Where personal myths are cheap to make and can multiply, the passage from the circle of makers into common life becomes the place where myth is decided, and confirmation becomes the practice’s characteristic risk. The unevenness of the record turns into a question about who can reach their own inheritance, and a practice that once seemed to need a Blake becomes open to people without his repertoire. Silver’s phrase for the shift, that taste is the new skill (Nasskau 2023), puts what remains of the old demand in recognition, the third moment of the spiral. An experiment with short fiction found the opening and the narrowing together. Writers given ideas from a model produced stories judged more creative, the least creative writers gaining most, and the stories came out more alike than stories written without the model (Doshi and Hauser 2024). The prefix marks a familiar kind of practice under conditions it had never met before.


Consider a woman who left the country she grew up in fifteen years ago. Two stories are on offer to her, the emigrant who succeeds and repays the sacrifice and the one who fails and goes home, and neither fits, because her life has settled into living between two places and the between has no story of its own. Suppose she brings this concern to several practices in turn.


A journal lets her write it out, and rereading returns her own words. The practice is recursive and self-forming and can surprise her, but its surplus is only what her words carry beyond her intent, since nothing arrives from outside her repertoire. Therapy gives her a trained other who returns interpretations within a frame designed for her relief, and correction is built in, because the therapist holds a standpoint of her own. What she keeps from it is understanding, stated in propositions and kept for repair. The I Ching might give her hexagram 56, the Wanderer, whose judgment reads “Success through smallness,” and whose commentary opens with advice for the wanderer and stranger (Wilhelm 1967). She may recognize herself in it. The figure is story-shaped and orienting, and it has held its authority for more than two thousand years among people who did not make it. She did not make it either, and the tradition tells her what it means, so divination places her inside an existing myth. A serial story written with a friend would give her a world with figures and a history, and it might come to orient her. It has two makers from its first page, though, each bringing a life and a stake and each free to stop, and its repertoire is what the two of them know. A single request to an image model for “a woman between two countries,” for the cover of a zine, might return a suitcase and a railway platform in sepia. Nothing recurs, nothing is kept as orientation, and the default has handed her one of the two stories she already knew did not fit.


Neomythism, in her case, would look like this. She returns to a model over months. The first returns are the default migrant, and she keeps none of them. Some weeks in, a figure arrives that she did not ask for, a ferrywoman who lives on the river and belongs to neither bank. The ferrywoman recurs and acquires a name and a history, and a small world of crossings grows around her, drawing on river figures from traditions the practitioner never studied. In time she finds that she thinks about her own life through this figure, the crossing as a place where one can live, and she does not argue herself into it. She recognizes it and returns to it, knowing that she helped make it. The ferrywoman now works on her as a myth works, and is a personal myth. If she puts the figure into circulation and other people who live between places take it up and retell it in their own ways, it begins to live beyond its makers.


The journal lacks the recursion’s third moment, a return from outside the practitioner’s repertoire, since what it returns is her own words. Therapy and the serial story have the recursion, and at their far pole stands a person whose life goes on outside the exchange and who can refuse the figure from there, which is the correction the private practice lacks. Whoever or whatever stands at the model’s pole has been tuned, in part, toward agreement with the one it answers (Section 5). Divination hands her a myth she had no part in making. The single request involves her in making something, and nothing it returns is kept or lived by. Neomythism is the case that has the recursion, the continuity, figures that work as myths work for the practitioner, and the knowledge of having helped to make them, together with two things the serial story lacks. Its returns draw on a repertoire far larger than the practitioner’s or any partner’s, and the party that answers has been tuned in part toward agreement and has no place in a common life from which to refuse the figure. Other holders come, if they come, afterward. The comparison also shows why the default mattered in her case. She could not be oriented by a figure that repeated a story she already knew did not fit, which is a point about her and implies nothing yet about what every practitioner ought to do.


Religious reconstructionism is a neighbor of another kind. It takes an inherited myth as the thing to be remembered rightly, and its relation to tradition is one of faithful transmission, while neomythism treats inherited material as input to a making whose outcome none of its sources anticipates. The wider Pagan revival reclaims and reinvents more freely, and it does so in communities, through shared ritual (Magliocco 2004), where neomythism begins in a single exchange and meets a community, if it meets one, afterward. What Xidakis (2022) calls neomythology, the recomposition of inherited religious and mythic figures across science fiction and popular culture, is something a scholar reads off finished cultural products. Neomythism is something a practitioner does, and the doing acts back on her.


## 7 The Politics of the Practice


The descriptive thesis of this paper is that generative systems can mediate recursive symbolic self-formation, and that one region of it, neomythism, makes figures with the form and force of myth. A thesis about which forms of the practice are better does not follow from it, and nothing in the definition requires the practitioner to oppose the culture’s defaults, or anything else. Myth-making can be devotional, therapeutic, nostalgic, conservative, escapist, emancipatory, or reactionary, and so can neomythism. A practitioner can work with a model to elaborate the saints of a tradition she loves, or to build a private world she retreats into, and someone else can work with the same models on a nation’s imagined golden age, heroic and pure, until it orients her, and then circulate it as an origin. Once it circulates as nature, that last is myth-making in Barthes’s exact sense, a contingent program given an eternal past, and the account describes the practice that produced it as neomythism without difficulty.


The normative thesis I defend is narrower than opposition. Because myth’s authority does not rest on argument, it can be checked in two ways. The people under its sway can see that it was made, and by whom, and others who did not make it can contest it. Barthesian myth removes both. It hides its making and presents its settlement as nature, and so it takes an orientation out of reach of revision by the people it orients. Liberal views of freedom make much of what Rawls called the capacity “to form, to revise, and rationally to pursue” a conception of a worthwhile life (Rawls 1993, p 302). Anyone who values that capacity has reason to think a practice of myth-making better, other things equal, when it keeps its making in view and stays answerable to people who did not make it. Call these avowal and answerability. The definition of neomythism already requires that the practitioner know she is among the makers of her figures; avowal asks further that the making stay in view for everyone the figures come to orient, the maker included, which is harder, since a figure lived with long enough can come to seem found. It does not ask her to settle how much of the figure came from her. Winnicott advised the adults around a small child never to ask whether its first treasured object had been made or found (Winnicott 1971), and a practitioner can keep the same tact toward herself while declining to tell anyone else that the figure was simply found. Neither standard is political in the partisan sense. A devotional practitioner who makes figures within her tradition, knowing she makes them and offering them to her community, meets both, and a progressive who presents a generated utopia as the natural order of things meets neither.


Analyzing photography, Flusser (2000) described the camera as an apparatus that comes with a program, a space of possible images it is built to produce, and the photographer as a functionary who operates within that program. Most users, on his account, actualize possibilities the apparatus already contains, and in doing so they serve it; the photographer who plays against the apparatus forces from it images its program did not anticipate. A generative model has a program in this sense, the set of tendencies that training and tuning fixed in place. Flusser located freedom in play against the program. The thesis defended here locates the better practice in seeing the program as a program, which leaves room to accept a default knowingly. It also leaves room for resistance in the name of fidelity. A practitioner whose tradition is thin in the model may have to work against the defaults to reach it. Asked for an angel, a model may return a winged Renaissance child where her tradition paints something else, and reaching her own angel takes work against the program for the sake of conserving what she inherited. Working against defaults, which in Barthes’s terms is the making of an artificial myth on top of a naturalized one so that its operation shows, is an important subtype of the practice, and it matters most where defaults are ideological in the sense of Section 3.


Who takes the practice up as a sustained discipline, as against an occasional diversion, is a further question. The account predicts that the practice becomes salient in a particular situation, when the stories a person, or a people, has inherited have stopped fitting the life being lived. Someone well served by the available myths has little reason to work consciously on the mythic layer, because it is already doing what she needs. Someone failed by them has every reason. It is a claim about motive, and it adds nothing to the definition.


The unevenness of the record described in Section 3 sets the scope of the account, and a global horizon makes the point pressing. If what a model returns is shaped by the record it learned from and the layers laid over it, then what counts as a default, and what it means to work with or against one, differs from one symbolic tradition to another. A practitioner prompting from within a densely digitized inheritance meets a pliable and familiar set of probable figures, and a practitioner prompting from within a thinly recorded one meets a sparse and often foreign one. Neomythism is therefore a family of practices, each indexed to the record it draws on and the position it works from, and a global account would have to be comparative, tracing how the practice changes as inheritance and its computational compression vary. The present paper marks the need for that study and does not attempt it.


The practice also invites the warm vocabulary of re-enchantment, and the vocabulary is partly apt. Gell (1992) located the enchantment of art in the opacity of the process that made the object, the gap between the thing’s presence and the viewer’s capacity to reconstruct how it came to be, and a generative model is close to a limit case on his account, since the process is opaque even to the one who prompted it. Weber (1946) gave modernity its self-description as a disenchanted age, in which everything can in principle be mastered by calculation, and Josephson-Storm (2017) has argued that the self-description was itself a myth. By the account in Section 2 it is one, a story of before and after that orients the moderns who tell it, holds for most of them without argument, and is retold by people who never made it. A practice that finds enchantment in some of the most calculated artifacts of the age sits awkwardly inside that story. Benjamin (1968) set a sharper puzzle. The aura of a traditional artwork was bound to its unique presence in time and space, and mechanical reproduction stripped it away. A generated image has no original at all, no negative and no first instance, and by Benjamin’s logic it should be aura’s opposite. It can nonetheless carry a charge, and telling that charge apart from nostalgia for the auratic is part of what a philosophy of the practice owes.


That vocabulary is also dangerous, because a source of enchantment invites celebration, and the celebration courts a techno-enthusiasm I want no part of. The same systems rest on costs in labor and energy that the warm vocabulary hides, and on moderation that decides in advance what may be depicted and what may circulate (Crawford 2021). To describe neomythism as enchantment without naming these conditions would be to perform the very Barthesian operation the account is trying to expose, making a contingent and costly arrangement look like simple wonder.


## 8 Objections


One objection holds that the model’s surplus is mere randomness, statistical noise onto which the practitioner projects a significance it does not carry, so that the whole account rests on a flattering description of a slot machine. Two things answer it. The surplus is structured. It comes from tendencies the model learned from an uneven record of what people have made, so what returns is shaped by some of the forces that shape the inherited imaginary. And the question of meaning is settled at the moment of recognition more than at the moment of generation. Meaning here is a relation between the returned image and a practitioner who finds something true in it, and the genealogy of the image does nothing to cancel that relation. A dream is assembled by processes opaque to the dreamer and loses no meaning on that account.


A second objection presses on the transformation. If the change in the practitioner is only felt, a warm subjective glow with no further standing, then the philosophical weight placed on it is unearned. The evidence offered here is structural and phenomenological, and a fuller case would need longitudinal study. Still, the transformation is anchored to a statable mechanism, the recognition and uptake of returns across many iterations, and a change produced by that mechanism has the same standing as any other case of learning through sustained engagement with a demanding medium. The felt quality registers the change without standing in for it. What the mechanism cannot guarantee is that the change is good, and the danger of confirmation described in Section 5 is the clearest reason it may not be.


The last objection is ethical, and it deserves to be left standing. If the practice depends on an apparatus built through appropriation and ecological cost, then perhaps its enchantments are compromised at the root, and the honest course is refusal. I have not argued that the practice is innocent, and Section 7 grants the costs. My argument is narrower. Within these conditions a real form of meaning-making is going on, its better forms keep their making in view and stay answerable to others, and understanding it is compatible with continuing to contest the conditions under which it operates. A philosophy that could describe only practices with clean hands would have very little to describe.


## 9 Limits of the Account


This is a conceptual paper, and it reports no data. What it offers is an account of how a practice is structured and of the conditions under which it runs. It does not estimate how widespread the practice is, and it cannot say what the practice does to the lives of those who pursue it. Where the paper describes what a practitioner does, it describes a characteristic structure, and the case in Section 6 is constructed to test the definition. It reports no one’s experience. Three claims in particular are stated as structure and would need empirical work to confirm. One is that the spiral, run long enough, reorganizes the practitioner. Another is that the danger of confirmation is characteristic of the private practice and more than an occasional failure, and the last is that people failed by their inherited stories are the ones most likely to take the practice up as a discipline. How often the practice takes the dyadic form, and how the relationships it involves develop, are empirical questions too. The account of myth in Section 2 is a proposal. Someone who holds that myth requires a religious community, or that it requires no narrative at all, will draw the lines elsewhere, and the argument shows only what follows if they are drawn as proposed. The technical description of models in Section 3 fits current systems and may date quickly, since the layers between corpus and output change with every product cycle. The account brackets the question of the machine’s interior, and a reader who holds that the question must be settled before the practice can be described will count that bracketing as a limit. Finally, the comparative study that the unevenness of the record calls for is marked here and not carried out.


## 10 Conclusion


I have argued that neomythism, the making of figures that come to work as myths for a practitioner in sustained exchange with generative systems, is best understood through a selective concept of myth. A myth is a story, or a figure condensing one, that orients a life, holds without argument, and lives beyond its makers. Measured against that account, the practice looks different from both descriptions it usually receives. What it keeps, it keeps as orientation, which the production frame cannot account for. Its relation to the machine’s defaults is also more varied than the extraction picture allows, since defaults become ideological, and ideology becomes mythic, only in circumstances that can be stated and that most defaults never meet. What the practice makes, before anyone beyond its makers takes it up, are myths in the making, personal myths in the solitary case, and the machine’s contribution is to make them available at a scale, and with a repertoire, that mythmaking by individuals and small groups never had.


The decisive moments of the practice are the recognition in which a figure first takes hold of a practitioner and the passage in which it takes hold of others, and neither can be read off the images alone. Its better forms keep their making in view and stay answerable to people who did not make them, a standard that applies to devotional and emancipatory neomythism alike and that the practice meets only by building in the correction a private scale lacks. The largest claim one might make for the practice, that it widens the jurisdiction of the possible, can be given a precise and modest sense. When a figure made in the practice passes into common life and gives people a way to imagine a life their inherited stories foreclosed, it enlarges, for them, the range of what can be thought and wanted. Circulation can also harden such a figure into the next generation’s formula (Section 5), and which of the two happens in a given case is a question for other methods. The concept of neomythism is meant to make the practice visible enough to be studied and held to that standard, and whether it earns continued use is a question its use will answer.


## References


Adler A (1956) The individual psychology of Alfred Adler: a systematic presentation in selections from his writings (Ansbacher HL, Ansbacher RR, eds). Basic Books, New York


Allado-McDowell K (2020) Pharmako-AI. Ignota Books, London


Barthes R (1972) Mythologies (Lavers A, trans). Hill and Wang, New York (Original work published 1957)


Benjamin W (1968) The work of art in the age of mechanical reproduction. In: Arendt H (ed) Illuminations (Zohn H, trans). Schocken Books, New York, pp 217–251 (Original work published 1936)


Bennett J (2001) The enchantment of modern life: attachments, crossings, and ethics. Princeton University Press, Princeton


Bianchi F, Kalluri P, Durmus E, Ladhak F, Cheng M, Nozza D, Hashimoto T, Jurafsky D, Zou J, Caliskan A (2023) Easily accessible text-to-image generation amplifies demographic stereotypes at large scale. In: Proceedings of the 2023 ACM conference on fairness, accountability, and transparency (FAccT ‘23). ACM, New York. [https://doi.org/10.1145/3593013.3594095](<https://doi.org/10.1145/3593013.3594095>)


Birhane A (2022) The unseen Black faces of AI algorithms. Nature 610(7932):451–452. [https://doi.org/10.1038/d41586-022-03050-7](<https://doi.org/10.1038/d41586-022-03050-7>)


Blake W (1988) The complete poetry and prose of William Blake (Erdman DV, ed), newly revised edn. Anchor Books, New York


Blumenberg H (1985) Work on myth (Wallace RM, trans). MIT Press, Cambridge, MA (Original work published 1979)


Brandtzaeg PB, Skjuve M, Følstad A (2022) My AI friend: how users of a social chatbot understand their human-AI friendship. Hum Commun Res 48(3):404–429. [https://doi.org/10.1093/hcr/hqac008](<https://doi.org/10.1093/hcr/hqac008>)


Cassirer E (1955) The philosophy of symbolic forms, vol 2: mythical thought (Manheim R, trans). Yale University Press, New Haven (Original work published 1925)


Castoriadis C (1987) The imaginary institution of society (Blamey K, trans). Polity Press, Cambridge (Original work published 1975)


Chang M, Druga S, Fiannaca AJ, Vergani P, Kulkarni C, Cai CJ, Terry M (2023) The prompt artists. In: Proceedings of the 15th conference on creativity and cognition (C&C ‘23). ACM, New York. [https://doi.org/10.1145/3591196.3593515](<https://doi.org/10.1145/3591196.3593515>)


Citton Y (2010) Mythocratie: storytelling et imaginaire de gauche. Éditions Amsterdam, Paris


Collingwood RG (1938) The principles of art. Clarendon Press, Oxford


Crawford K (2021) Atlas of AI: power, politics, and the planetary costs of artificial intelligence. Yale University Press, New Haven


Dodge J, Sap M, Marasović A, Agnew W, Ilharco G, Groeneveld D, Mitchell M, Gardner M (2021) Documenting large webtext corpora: a case study on the colossal clean crawled corpus. In: Proceedings of the 2021 conference on empirical methods in natural language processing. Association for Computational Linguistics, pp 1286–1305. [https://doi.org/10.18653/v1/2021.emnlp-main.98](<https://doi.org/10.18653/v1/2021.emnlp-main.98>)


Doshi AR, Hauser OP (2024) Generative AI enhances individual creativity but reduces the collective diversity of novel content. Sci Adv 10(28):eadn5290. [https://doi.org/10.1126/sciadv.adn5290](<https://doi.org/10.1126/sciadv.adn5290>)


Flusser V (2000) Towards a philosophy of photography (Mathews A, trans). Reaktion Books, London (Original work published 1983)


Gell A (1992) The technology of enchantment and the enchantment of technology. In: Coote J, Shelton A (eds) Anthropology, art and aesthetics. Clarendon Press, Oxford, pp 40–63


Geuss R (1981) The idea of a critical theory: Habermas and the Frankfurt School. Cambridge University Press, Cambridge


Herndon H, Dryhurst M (2024) xhairymutantx \[text-to-image model and online work\]. Whitney Biennial 2024, Whitney Museum of American Art, New York. [https://whitney.org/exhibitions/xhairymutantx](<https://whitney.org/exhibitions/xhairymutantx>)


Hillman J (1975) Re-visioning psychology. Harper & Row, New York


Josephson-Storm JĀ (2017) The myth of disenchantment: magic, modernity, and the birth of the human sciences. University of Chicago Press, Chicago


Joshi P, Santy S, Budhiraja A, Bali K, Choudhury M (2020) The state and fate of linguistic diversity and inclusion in the NLP world. In: Proceedings of the 58th annual meeting of the Association for Computational Linguistics. Association for Computational Linguistics, pp 6282–6293. [https://doi.org/10.18653/v1/2020.acl-main.560](<https://doi.org/10.18653/v1/2020.acl-main.560>)


Jung CG (1964) Man and his symbols. Aldus Books, London


Jung CG (1968) The archetypes and the collective unconscious, 2nd edn. The collected works of C. G. Jung, vol 9, part I (Hull RFC, trans; McGuire W, ed). Bollingen Series XX. Princeton University Press, Princeton (Original work published 1959)


Jung CG (1989) Memories, dreams, reflections (Jaffé A, ed; Winston R, Winston C, trans). Vintage Books, New York (Original work published 1962)


Land N (2009) Hyperstition: an introduction (interview by Carstens D). 0rphan Drift Archive. [https://www.orphandriftarchive.com/articles/hyperstition-an-introduction/](<https://www.orphandriftarchive.com/articles/hyperstition-an-introduction/>). Accessed 23 September 2026


Lévi-Strauss C (1955) The structural study of myth. J Am Folklore 68(270):428–444. [https://doi.org/10.2307/536768](<https://doi.org/10.2307/536768>)


Lévi-Strauss C (1963) Structural anthropology (Jacobson C, Schoepf BG, trans). Basic Books, New York (Original work published 1958)


Lévi-Strauss C (1966) The savage mind. University of Chicago Press, Chicago (Original work published 1962)


Lévi-Strauss C (1978) Myth and meaning. Routledge & Kegan Paul, London


Lincoln B (1989) Discourse and the construction of society: comparative studies of myth, ritual, and classification. Oxford University Press, New York


Lincoln B (1999) Theorizing myth: narrative, ideology, and scholarship. University of Chicago Press, Chicago


MacIntyre A (2007) After virtue: a study in moral theory, 3rd edn. University of Notre Dame Press, Notre Dame (Original work published 1981)


Magliocco S (2004) Witching culture: folklore and Neo-Paganism in America. University of Pennsylvania Press, Philadelphia


Margulis L (1970) Origin of eukaryotic cells. Yale University Press, New Haven


Margulis L (1998) Symbiotic planet: a new look at evolution. Basic Books, New York


Massumi B (2002) Parables for the virtual: movement, affect, sensation. Duke University Press, Durham


Maynard Smith J, Szathmáry E (1995) The major transitions in evolution. Oxford University Press, Oxford


Nasskau L (2023) Taste is the new skill: Claire Silver on the future of AI-driven culture. Culture3, 25 July 2023. [https://www.culture3.com/posts/claire-silver-on-why-taste-is-the-new-skill-and-the-future-of-ai-driven-culture](<https://www.culture3.com/posts/claire-silver-on-why-taste-is-the-new-skill-and-the-future-of-ai-driven-culture>). Accessed 23 September 2026


Ogden TH (1994) The analytic third: working with intersubjective clinical facts. Int J Psychoanal 75(1):3–19


Oppenlaender J (2024) A taxonomy of prompt modifiers for text-to-image generation. Behav Inf Technol 43(15):3763–3776. [https://doi.org/10.1080/0144929X.2023.2286532](<https://doi.org/10.1080/0144929X.2023.2286532>)


Rawls J (1993) Political liberalism. Columbia University Press, New York


Ricoeur P (1967) The symbolism of evil (Buchanan E, trans). Harper & Row, New York (Original work published 1960)


Rowland S (2002) Jung: a feminist revision. Polity Press, Cambridge


Sharma M, Tong M, Korbak T, Duvenaud D, Askell A, Bowman SR, Cheng N, Durmus E, Hatfield-Dodds Z, Johnston SR, Kravec S, Maxwell T, McCandlish S, Ndousse K, Rausch O, Schiefer N, Yan D, Zhang M, Perez E (2024) Towards understanding sycophancy in language models. In: The twelfth international conference on learning representations (ICLR 2024). [https://doi.org/10.48550/arXiv.2310.13548](<https://doi.org/10.48550/arXiv.2310.13548>)


Shumailov I, Shumaylov Z, Zhao Y, Papernot N, Anderson R, Gal Y (2024) AI models collapse when trained on recursively generated data. Nature 631:755–759. [https://doi.org/10.1038/s41586-024-07566-y](<https://doi.org/10.1038/s41586-024-07566-y>)


Silver C (n.d.) About. [https://www.clairesilver.com/about](<https://www.clairesilver.com/about>). Accessed 23 September 2026


Skjuve M, Følstad A, Fostervold KI, Brandtzaeg PB (2021) My chatbot companion: a study of human-chatbot relationships. Int J Hum-Comput Stud 149:102601. [https://doi.org/10.1016/j.ijhcs.2021.102601](<https://doi.org/10.1016/j.ijhcs.2021.102601>)


Stiegler B (2009) Technics and time, 2: disorientation (Barker S, trans). Stanford University Press, Stanford (Original work published 1996)


Strawson G (2004) Against narrativity. Ratio 17(4):428–452. [https://doi.org/10.1111/j.1467-9329.2004.00264.x](<https://doi.org/10.1111/j.1467-9329.2004.00264.x>)


Taylor C (2004) Modern social imaginaries. Duke University Press, Durham


Vaihinger H (1924) The philosophy of ‘as if’: a system of the theoretical, practical and religious fictions of mankind (Ogden CK, trans). Routledge & Kegan Paul, London (Original work published 1911)


Weber M (1946) Science as a vocation. In: Gerth HH, Mills CW (eds) From Max Weber: essays in sociology. Oxford University Press, New York, pp 129–156 (Original work published 1919)


Wehr DS (1987) Jung and feminism: liberating archetypes. Beacon Press, Boston


Wilhelm R (1967) The I Ching or book of changes (Baynes CF, trans), 3rd edn. Princeton University Press, Princeton (Original work published 1924)


Winnicott DW (1971) Playing and reality. Tavistock Publications, London


Wittgenstein L (1958) Philosophical investigations, 2nd edn (Anscombe GEM, trans). Blackwell, Oxford (Original work published 1953)


Xidakis I (2022) Neomythology: a new religious mythology. Religions 13(6):536. [https://doi.org/10.3390/rel13060536](<https://doi.org/10.3390/rel13060536>)


Yeats WB (1937) A vision. Macmillan, London


Zhou E, Lee D (2024) Generative artificial intelligence, human creativity, and art. PNAS Nexus 3(3):pgae052. [https://doi.org/10.1093/pnasnexus/pgae052](<https://doi.org/10.1093/pnasnexus/pgae052>)


## Edition and reuse notice

Rae de Lune, *Made and Real: Neomythism and the Life of Myth Beyond Its Makers*, Global Philosophy 36, article 31 (2026). [Published article](https://doi.org/10.1007/s10516-026-09804-6). Licensed under [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/). This edition converts presentation to Markdown/HTML, adjusts heading levels and links, and adds editorial metadata; the selected article text is preserved. Source notices and any third-party exceptions remain applicable. The linked PDF is unchanged.
