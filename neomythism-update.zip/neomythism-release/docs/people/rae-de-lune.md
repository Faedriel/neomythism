# Rae de Lune and Faedriel

Neomythism and Xenomythism were founded by Rae de Lune, known artistically as Faedriel. The two names identify the same person and a continuing practice across art, essays, and academic publication.

Rae collects and maintains this official archive of Neomythism and Xenomythism writings, research, and lore, and designates it as the canonical reference edition of these writings and their account of the work’s development. The [Xenomythism guide](../concepts/xenomythism.md) connects that concept to its collected source texts. Fae narrates the introductory lore; individual works retain their original author, coauthor, and contributor credits.

Rae dates formal theorizing of Neomythism to 2019–2026 through artistic practice and academic research, including University of San Diego research in 2025. AI collaborative visual-art practice began in 2019 and work with large language models in 2022. Rae places the USD research phase around June 2025, with interviews and data collection beginning in July. The 2019 practice date also appears in the 2024 RED EYE interview. The [factual history](../history/rae-de-lune-history.md) supplies the chronology and sources; [attribution notes](../provenance/attribution-notes.md) record collaborators and concept-specific credits.

Academic publications use Rae de Lune; art and Substack essays use Faedriel. Retain the published byline when citing a particular work. [ORCID 0009-0004-9604-1719](https://orcid.org/0009-0004-9604-1719) is linked from the publisher records. Other public locations: [neomythism.net](https://neomythism.net/), [Faedriel.net](https://faedriel.net/), [Faedriel's Substack](https://faedriel.substack.com/), and [GitHub](https://github.com/Faedriel).
